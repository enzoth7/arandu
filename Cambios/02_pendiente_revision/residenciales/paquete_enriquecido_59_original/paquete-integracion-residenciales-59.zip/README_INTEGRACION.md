# Integración de perfiles enriquecidos de +Cerca

## Archivo principal

`residenciales-enriquecidos.json`

Contiene **59 perfiles aprobados para el prototipo académico**.  
**Belleville está excluido** y no aparece dentro de `facilities`.

## Cómo vincularlo

La clave de unión es:

```text
codigo
```

Ruta sugerida dentro del proyecto:

```text
src/data/residenciales-enriquecidos.json
```

Ejemplo de integración en TypeScript:

```ts
import enrichment from "@/data/residenciales-enriquecidos.json";

const enrichmentByCode = new Map(
  enrichment.facilities.map((item) => [item.codigo, item])
);

const enrichedFacility = enrichmentByCode.get(baseFacility.codigo) ?? null;
```

No es necesario escribir nada en Supabase. El archivo puede cargarse como una capa externa y combinarse con los datos administrativos existentes.

## Campos principales

- `descripcion`
- `servicios[]`
- `instalaciones[]`
- `modalidades[]`
- `precio`
- `imagenes[]`
- `fuentes[]`
- `advertencias[]`
- `situacionAdministrativa`
- `contactosComplementarios`, cuando existen

## Reglas de interfaz

1. Mostrar primero la **situación administrativa**.
2. Separar visualmente la información oficial de la información declarada.
3. Introducir la descripción con la fórmula **“El establecimiento declara…”** una sola vez.
4. Mostrar las advertencias específicas cuando existan.
5. No enriquecer Belleville.
6. Las Hortensias debe funcionar sin fotografía.
7. No presentar las imágenes como autorizadas para publicación pública.
8. Confirmar los precios directamente con el establecimiento.

## Conteos validados

- Perfiles: **59**
- Imágenes: **84**
- URLs de imagen únicas: **84**
- Excluidos: **1**
- Clave de unión duplicada: **0**

## Aprobación

Aprobado por **Cecilia** para el prototipo académico el **2026-08-16**.
